import React, { useEffect, useState } from "react";
import { faker } from "@faker-js/faker";
import { supabase } from "../supabaseClient";

function generateFakeMessages(qtd = 5) {
  return Array.from({ length: qtd }).map(() => ({
    id: faker.string.uuid(),
    name: faker.person.firstName(),
    avatar: faker.image.avatar(),
    message: faker.lorem.sentence(),
    created_at: faker.date.recent().toLocaleString("pt-BR"),
    fake: true,
  }));
}

export default function ExclusiveChat({ user, pontos }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  useEffect(() => {
    if (pontos < 50000) return;
    async function fetchMessages() {
      const { data, error } = await supabase
        .from("chat")
        .select("id, user:user_id (name, avatar_url), message, created_at")
        .order("created_at", { ascending: false })
        .limit(10);
      let realMsgs = [];
      if (!error && data) {
        realMsgs = data.map((msg) => ({
          id: msg.id,
          name: msg.user?.name || "Usuário",
          avatar: msg.user?.avatar_url || "https://i.pravatar.cc/40",
          message: msg.message,
          created_at: new Date(msg.created_at).toLocaleString("pt-BR"),
          fake: false,
        }));
      }
      setMessages([...generateFakeMessages(5), ...realMsgs]);
    }
    fetchMessages();
  }, [pontos]);

  async function sendMessage(e) {
    e.preventDefault();
    if (!input.trim()) return;
    await supabase.from("chat").insert([
      {
        user_id: user.id,
        message: input,
        created_at: new Date(),
      },
    ]);
    setInput("");
    // Opcional: recarregar mensagens
  }

  if (pontos < 50000) {
    return (
      <div style={{
        background: "#fffde7",
        border: "1px solid #ffd600",
        borderRadius: 8,
        padding: 24,
        margin: "2rem auto",
        maxWidth: 500,
        textAlign: "center"
      }}>
        <div style={{ fontSize: 32, color: "#ffd600" }}>🔒</div>
        <h3>Chat exclusivo</h3>
        <p>Disponível apenas para quem tem mais de <b>50.000 pontos</b>.</p>
      </div>
    );
  }

  return (
    <section style={{
      background: "#fff",
      border: "1px solid #ffd600",
      borderRadius: 8,
      padding: 24,
      margin: "2rem auto",
      maxWidth: 500,
    }}>
      <h3 style={{ color: "#ffd600" }}>Chat VIP</h3>
      <div style={{ maxHeight: 300, overflowY: "auto", marginBottom: 16 }}>
        {messages.map((msg) => (
          <div key={msg.id} style={{
            display: "flex",
            alignItems: "center",
            marginBottom: 12,
            opacity: msg.fake ? 0.7 : 1
          }}>
            <img src={msg.avatar} alt={msg.name} style={{
              width: 32, height: 32, borderRadius: "50%", marginRight: 8, border: "2px solid #ffd600"
            }} />
            <div>
              <div style={{ fontWeight: "bold", color: "#222" }}>{msg.name}</div>
              <div style={{ color: "#444" }}>{msg.message}</div>
              <div style={{ fontSize: 12, color: "#aaa" }}>{msg.created_at}</div>
            </div>
          </div>
        ))}
      </div>
      <form onSubmit={sendMessage} style={{ display: "flex", gap: 8 }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Digite sua mensagem..."
          style={{
            flex: 1,
            padding: 8,
            borderRadius: 6,
            border: "1px solid #ffd600"
          }}
        />
        <button
          type="submit"
          style={{
            background: "#ffd600",
            color: "#222",
            border: "none",
            borderRadius: 6,
            padding: "0 16px",
            fontWeight: "bold"
          }}
        >
          Enviar
        </button>
      </form>
    </section>
  );
}