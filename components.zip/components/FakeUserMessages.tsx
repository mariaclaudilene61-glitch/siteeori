import React from "react";
import { faker } from "@faker-js/faker";

function generateFakeMessages(qtd = 5) {
  return Array.from({ length: qtd }).map(() => ({
    id: faker.string.uuid(),
    name: faker.person.firstName(),
    avatar: faker.image.avatar(),
    message: faker.lorem.sentence(),
    created_at: faker.date.recent().toLocaleString("pt-BR"),
  }));
}

export default function FakeUserMessages({ qtd = 5 }) {
  const messages = generateFakeMessages(qtd);

  return (
    <div>
      <h3 style={{ color: "#ffd600" }}>Mensagens de Usuários</h3>
      {messages.map((msg) => (
        <div
          key={msg.id}
          style={{
            display: "flex",
            alignItems: "center",
            marginBottom: 16,
            background: "#fff",
            border: "1px solid #ffd600",
            borderRadius: 8,
            padding: 12,
            gap: 12,
            opacity: 0.8,
          }}
        >
          <img
            src={msg.avatar}
            alt={msg.name}
            style={{
              width: 36,
              height: 36,
              borderRadius: "50%",
              border: "2px solid #ffd600",
            }}
          />
          <div>
            <div style={{ fontWeight: "bold", color: "#222" }}>{msg.name}</div>
            <div style={{ color: "#444" }}>{msg.message}</div>
            <div style={{ fontSize: 12, color: "#aaa" }}>{msg.created_at}</div>
          </div>
        </div>
      ))}
    </div>
  );
}