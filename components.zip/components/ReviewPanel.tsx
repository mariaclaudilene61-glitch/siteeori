import React, { useEffect, useState } from "react";
import { supabase } from "../supabaseClient";

export default function ReviewPanel() {
  const [reviews, setReviews] = useState([]);

  useEffect(() => {
    async function fetchReviews() {
      const { data, error } = await supabase
        .from("reviews")
        .select("id, stars, detail, created_at, user:user_id (name, avatar_url)")
        .order("created_at", { ascending: false })
        .limit(10);
      if (!error) setReviews(data || []);
    }
    fetchReviews();
  }, []);

  return (
    <section
      style={{
        background: "#fff",
        border: "1px solid #ffd600",
        borderRadius: "8px",
        padding: "1.5rem",
        margin: "2rem auto",
        maxWidth: "600px",
      }}
    >
      <h2 style={{ color: "#ffd600" }}>Últimas Avaliações</h2>
      {reviews.length === 0 && <div>Nenhuma avaliação ainda.</div>}
      {reviews.map((r) => (
        <div
          key={r.id}
          style={{
            borderBottom: "1px solid #ffe082",
            padding: "1rem 0",
            display: "flex",
            alignItems: "flex-start",
            gap: "1rem",
          }}
        >
          <img
            src={r.user?.avatar_url || "https://i.pravatar.cc/40"}
            alt={r.user?.name || "Usuário"}
            style={{
              width: 40,
              height: 40,
              borderRadius: "50%",
              border: "2px solid #ffd600",
            }}
          />
          <div>
            <div style={{ fontWeight: "bold", color: "#222" }}>
              {r.user?.name || "Usuário"}
            </div>
            <div style={{ color: "#ffd600", fontSize: "1.1rem" }}>
              {"★".repeat(r.stars)}{" "}
              <span style={{ color: "#ccc" }}>
                {"★".repeat(5 - r.stars)}
              </span>
            </div>
            <div style={{ color: "#444", marginTop: 4 }}>{r.detail}</div>
            <div style={{ fontSize: "0.8rem", color: "#aaa", marginTop: 2 }}>
              {new Date(r.created_at).toLocaleString("pt-BR")}
            </div>
          </div>
        </div>
      ))}
    </section>
  );
}