import React from "react";
import { supabase } from "../supabaseClient";

export default function Login() {
  const handleLogin = async () => {
    await supabase.auth.signInWithOAuth({ provider: "google" });
  };

  return (
    <div className="login-container" style={{
      background: "#fffbe6",
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center"
    }}>
      <div style={{
        fontSize: "3rem",
        color: "#ffd600",
        marginBottom: "1rem"
      }}>🏆</div>
      <h2>Bem-vindo ao Avaliador de Livros</h2>
      <button
        onClick={handleLogin}
        style={{
          background: "#ffd600",
          color: "#222",
          border: "none",
          padding: "0.8rem 2rem",
          borderRadius: "8px",
          fontSize: "1.1rem",
          cursor: "pointer",
          marginTop: "1.5rem"
        }}
      >
        Entrar com Google
      </button>
    </div>
  );
}