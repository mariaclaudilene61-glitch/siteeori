import React, { useState } from "react";
import { supabase } from "../supabaseClient";

export default function BookReviewForm({ user, isVip, freeReviewsLeft, onReview }) {
  const [stars, setStars] = useState(0);
  const [question1, setQuestion1] = useState("");
  const [question2, setQuestion2] = useState("");
  const [detail, setDetail] = useState("");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  // Pontuação por avaliação
  const pointsPerReview = isVip ? 50 : freeReviewsLeft > 0 ? 150 : 0;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (stars === 0 || !detail) {
      setMsg("Preencha todos os campos obrigatórios.");
      return;
    }
    setLoading(true);

    // Salva avaliação no Supabase
    const { error } = await supabase.from("reviews").insert([
      {
        user_id: user.id,
        stars,
        question1,
        question2,
        detail,
        created_at: new Date(),
      },
    ]);
    if (error) {
      setMsg("Erro ao salvar avaliação.");
      setLoading(false);
      return;
    }

    // Atualiza pontos do usuário
    let bonus = isVip ? 100 : 0;
    await supabase
      .from("users")
      .update({
        pontos: (user.pontos || 0) + pointsPerReview + bonus,
        avaliacoes_gratis_restantes: isVip
          ? freeReviewsLeft
          : Math.max(0, freeReviewsLeft - 1),
      })
      .eq("id", user.id);

    setMsg("Avaliação enviada! Pontos creditados.");
    setLoading(false);
    setStars(0);
    setQuestion1("");
    setQuestion2("");
    setDetail("");
    if (onReview) onReview();
  }

  return (
    <form className="review-form" onSubmit={handleSubmit}>
      <h3>Avalie um livro</h3>
      <div>
        <label>Nota:</label>
        {[1, 2, 3, 4, 5].map((n) => (
          <span
            key={n}
            style={{ color: n <= stars ? "#ffd600" : "#ccc", cursor: "pointer", fontSize: "1.5rem" }}
            onClick={() => setStars(n)}
          >
            ★
          </span>
        ))}
      </div>
      <div>
        <label>Pergunta 1: O que mais gostou?</label>
        <input value={question1} onChange={e => setQuestion1(e.target.value)} required />
      </div>
      <div>
        <label>Pergunta 2: Recomendaria?</label>
        <select value={question2} onChange={e => setQuestion2(e.target.value)} required>
          <option value="">Selecione</option>
          <option value="sim">Sim</option>
          <option value="nao">Não</option>
        </select>
      </div>
      <div>
        <label>Comentário detalhado:</label>
        <textarea value={detail} onChange={e => setDetail(e.target.value)} required />
      </div>
      <button type="submit" disabled={loading || pointsPerReview === 0}>
        {loading ? "Enviando..." : `Enviar avaliação (+${pointsPerReview}${isVip ? " +100 bônus VIP" : ""} pts)`}
      </button>
      {pointsPerReview === 0 && <div>Limite de avaliações grátis atingido. Torne-se VIP!</div>}
      {msg && <div>{msg}</div>}
    </form>
  );
}